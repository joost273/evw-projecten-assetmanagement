# EVW Projecten & Assetmanagement — website

Eerste versie van de website voor EVW Projecten & Assetmanagement (Eddie van Warmerdam).
Statische one-page site zonder build-stap of dependencies.

## Structuur

```
evw/
├── index.html        alle secties: header, hero, introductie, diensten, showcase, werkwijze,
│                     project + asset, waarom tijdelijk, over Eddie, contact, footer
├── css/styles.css    tokens, typografie, layouts, animaties, responsive regels, reduced-motion
├── js/main.js        header-gedrag, mobiel menu, scroll-reveals, parallax (geen dependencies)
├── img/              tijdelijke placeholderbeelden (SVG), zie hieronder
├── favicon.svg       tijdelijk favicon op basis van het woordmerk
└── serve.js          lokale previewserver: node serve.js 5260
```

Lokaal bekijken: `node serve.js` en open http://localhost:5260.

## Identiteit

- **Kleuren:** warm off-white (`#f3f0ea`), antraciet (`#1e2023`), gedempt groen als accent (`#46605b`, licht `#8aa39d`, donker `#2a3d39`). Alle kleuren staan als CSS-variabelen bovenin `css/styles.css`.
- **Typografie:** Instrument Serif (koppen) en Instrument Sans (lopende tekst), geladen via Google Fonts. Fallbacks: Georgia en Helvetica/Arial.
- **Woordmerk:** tijdelijk typografisch woordmerk `EVW` met daaronder `Projecten & Assetmanagement`. Het staat in `index.html` in de header (`.brand`) en in de footer (`.footer-brand`). Vervang beide blokken zodra het definitieve logo beschikbaar is.

## Beelden die nog verzameld moeten worden

Alle beelden zijn nu SVG-placeholders. Vervang het bestand of pas het `src`-attribuut aan in `index.html`; onder elk beeld staat een klein bijschrift (`.media-tag`) met het nummer, dat je kunt weghalen zodra de echte foto staat.

| Nr | Onderwerp | Placeholder | Gebruikt in | Formaat / advies |
| --- | --- | --- | --- | --- |
| 01 | Sterke hero-afbeelding van moderne, hoogwaardige architectuur | `img/placeholder-hero.svg` | Hero (rechts, hoog beeld) | Staand, ca. 4:5, minimaal 1600 px hoog |
| 02 | Kantoor- of utiliteitsgebouw | `img/placeholder-kantoor.svg` | Full-width showcase ("Projecten / Assets / Resultaat") | Liggend, 16:10, minimaal 2400 px breed |
| 03 | Modern woongebouw | `img/placeholder-wonen.svg` | Contactsectie (rechts, gedempt achter de tekst) | Staand, 4:5 |
| 04 | Detail van architectuur of materialen | `img/placeholder-detail.svg` | Sectie "Waarom tijdelijk" | Liggend, 4:3 |
| 05 | Professionele foto van Eddie van Warmerdam | `img/placeholder-portret.svg` | Sectie "Over Eddie" | Staand, 3:4, rustige achtergrond |
| 06 | Foto's van echte projecten (optioneel) | n.v.t. | Nog geen plek; kan later als projectoverzicht worden toegevoegd | — |

Vermijd generieke stockfoto's met handen schudden of mensen die naar laptops wijzen.
Bij vervanging: pas ook de `width`/`height`-attributen van het `<img>`-element aan naar de echte afmetingen, zodat de layout niet verspringt tijdens laden.

Voor social sharing verwacht de `og:image`-meta een bestand `img/og-image.jpg` (1200×630). Dat bestaat nog niet.

## Informatie die nog ingevuld moet worden

Placeholders staan tussen rechte haken en zijn gestyled met de class `.placeholder`:

- `[TELEFOONNUMMER]` — contactsectie en footer
- `[ADRES/REGIO]` — over Eddie (werkgebied), contactsectie en footer
- `[KVK]` — footer
- `[LINKEDIN]` — footer (maak er een link van zodra de URL bekend is)
- Achtergrond en ervaring van Eddie: in `index.html` staat in de sectie "Over Eddie" een uitgecommentarieerde regel in de feitenlijst (`.facts`) waar dit toegevoegd kan worden.
- Domein: `canonical`, `og:url` en de JSON-LD in de `<head>` gaan uit van `https://www.evwprojectenassetmanagement.com/`. Pas aan als het domein anders wordt.

Er zijn bewust geen projecten, opdrachtgevers, resultaten, percentages, certificeringen of reviews opgenomen.

## Breakpoints

- Desktop: vanaf 1181 px (12-koloms hero, vijf werkwijze-stappen naast elkaar)
- Klein desktop / tablet liggend: 961–1180 px (werkwijze in drie kolommen)
- Tablet staand: 641–960 px (menu-overlay, enkele kolommen, hero-beeld onder de tekst)
- Mobiel: tot 640 px (compacte lijsten, diagram als tags, knoppen op volle breedte)

## Toegankelijkheid en motion

- Semantische landmarks, skip-link, zichtbare focus-states, beschrijvende alt-teksten
- Mobiel menu met `aria-expanded`, sluit met Escape en bij klikken op een link
- `prefers-reduced-motion` schakelt reveals, parallax en de hero-animatie uit
- Zonder JavaScript is de volledige pagina zichtbaar (reveals worden alleen met JS geactiveerd)

## Later uitbreiden

- Projectenoverzicht of cases zodra er echte projecten gedeeld mogen worden
- Contactformulier (nu bewust alleen `mailto:`)
- Privacyverklaring en eventuele algemene voorwaarden als aparte pagina's
