/* EVW Projecten & Assetmanagement
   Header, mobiel menu, scroll-reveals, parallax. Geen dependencies. */
(function () {
  'use strict';

  var doc = document.documentElement;
  var body = document.body;
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Laadsequentie ---------- */
  function markLoaded() { body.classList.add('is-loaded'); }
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(markLoaded);
    setTimeout(markLoaded, 1200);
  } else {
    setTimeout(markLoaded, 150);
  }

  /* ---------- Header ---------- */
  var header = document.querySelector('.site-header');
  var lastY = window.scrollY;
  var ticking = false;

  function updateHeader() {
    var y = window.scrollY;
    header.classList.toggle('is-scrolled', y > 24);
    if (!body.classList.contains('menu-is-open')) {
      var goingDown = y > lastY && y > 400;
      header.classList.toggle('is-hidden', goingDown);
    }
    lastY = y;
  }

  /* ---------- Parallax ---------- */
  var parallaxItems = [];
  if (!reduceMotion) {
    parallaxItems = Array.prototype.map.call(document.querySelectorAll('[data-parallax]'), function (img) {
      return { el: img, factor: parseFloat(img.getAttribute('data-parallax')) || 0.1, box: img.parentElement };
    });
  }

  function updateParallax() {
    var vh = window.innerHeight;
    for (var i = 0; i < parallaxItems.length; i++) {
      var item = parallaxItems[i];
      var r = item.box.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh) continue;
      var center = r.top + r.height / 2 - vh / 2;
      var offset = -center * item.factor;
      item.el.style.setProperty('--py', offset.toFixed(1) + 'px');
    }
  }

  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      updateHeader();
      updateParallax();
      ticking = false;
    });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  header.addEventListener('focusin', function () { header.classList.remove('is-hidden'); });
  window.addEventListener('resize', onScroll);
  updateHeader();
  updateParallax();

  /* ---------- Mobiel menu ---------- */
  var toggle = document.querySelector('.menu-toggle');
  var menu = document.getElementById('mobile-menu');

  function openMenu() {
    menu.hidden = false;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { menu.classList.add('is-open'); });
    });
    header.classList.add('menu-open');
    header.classList.remove('is-hidden');
    body.classList.add('menu-is-open');
    toggle.setAttribute('aria-expanded', 'true');
    toggle.querySelector('.menu-toggle-label').textContent = 'Sluiten';
  }

  function closeMenu() {
    menu.classList.remove('is-open');
    header.classList.remove('menu-open');
    body.classList.remove('menu-is-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.querySelector('.menu-toggle-label').textContent = 'Menu';
    var delay = reduceMotion ? 0 : 450;
    setTimeout(function () { if (!menu.classList.contains('is-open')) menu.hidden = true; }, delay);
  }

  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      if (menu.hidden) openMenu(); else closeMenu();
    });
    menu.addEventListener('click', function (e) {
      var link = e.target.closest('a');
      if (!link) return;
      var href = link.getAttribute('href');
      var target = href && href.charAt(0) === '#' ? document.querySelector(href) : null;
      closeMenu();
      if (!target) return;
      /* Eerst de scroll-lock opheffen, dan pas scrollen: anders wordt de smooth scroll afgebroken. */
      e.preventDefault();
      requestAnimationFrame(function () {
        target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
        if (history.pushState) history.pushState(null, '', href);
      });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !menu.hidden) { closeMenu(); toggle.focus(); }
    });
    window.matchMedia('(min-width: 961px)').addEventListener('change', function (mq) {
      if (mq.matches && !menu.hidden) closeMenu();
    });
  }

  /* ---------- Scroll-reveals ---------- */
  var revealTargets = document.querySelectorAll('.reveal, .reveal-img, .intro-diagram, .span-diagram, .step');
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0, rootMargin: '0px 0px -8% 0px' });
    revealTargets.forEach(function (el) { io.observe(el); });
  } else {
    revealTargets.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- Jaartal ---------- */
  var year = document.getElementById('year');
  if (year) year.textContent = String(new Date().getFullYear());
})();
